# myapp/urls.py

from django.shortcuts import render
from django.urls import path
from .views import search_google

urlpatterns = [
    path('', lambda request: render(request, 'index.html'), name='home'),  # Home page
    path('search/', search_google, name='search_google'),  # Search results
]
