from django.shortcuts import render
from django.http import JsonResponse
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def search_google(request):
    query = request.GET.get('query', 'example')  # Get the search query from the request
    results = []

    # Set up Chrome options for headless mode
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Run in headless mode
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    chrome_driver_path = 'chromedriver.exe'  # Update this path
    service = Service(chrome_driver_path)
    driver = webdriver.Chrome(service=service, options=chrome_options)

    try:
        # Perform the Google search
        driver.get("https://www.google.com")
        search_box = driver.find_element(By.NAME, "q")
        search_box.send_keys(query)
        search_box.submit()

        # Wait for results to load
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "h3"))
        )

        # Get the search results
        links = driver.find_elements(By.CSS_SELECTOR, "a")

        # Extract URLs
        search_results = []
        for link in links:
            url = link.get_attribute('href')
            if url:
                search_results.append(url)

    finally:
        driver.quit()

        

    return render(request, 'results.html', {'results': search_results})
